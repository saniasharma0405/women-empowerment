const express = require("express");
const { registerUser, loginUser, getProfile } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/health", (req, res) => {
    res.json({ status: "ok" });
});

router.post("/register", registerUser);
router.post("/login", loginUser);
router.get("/me", protect, getProfile);

module.exports = router;

const express = require("express");
const mongoose = require("mongoose");
const Profile = require("../models/Profile");
const MentorshipRequest = require("../models/MentorshipRequest");
const Job = require("../models/Job");
const JobApplication = require("../models/JobApplication");
const Post = require("../models/Post");

const router = express.Router();
const safeText = (value, max = 1000) => (typeof value === "string" ? value.trim().slice(0, max) : "");

const fallbackProfile = {
    fullName: "Aisha Khan",
    email: "aisha.khan@example.com",
    location: "Karachi, Pakistan",
    headline: "Founder at Thread & Bloom | Building a thoughtful fashion label",
    bio: "I am growing a sustainable fashion business and learning to scale with confidence.",
    skills: ["Entrepreneurship", "Product design", "Digital marketing"],
    goals: "Build a stronger online presence and reach new customers.",
};

const fallbackRequests = [
    { id: "ment-1001", name: "Samira Noor", email: "samira@example.com", area: "Career growth", mentor: "Zoya Ahmed", message: "I am preparing for a transition into product leadership.", status: "New", createdAt: "2026-10-28" },
    { id: "ment-1002", name: "Mina Rahman", email: "mina@example.com", area: "Business growth", mentor: "Mariam Hassan", message: "Looking for advice on pricing and first hires.", status: "Reviewing", createdAt: "2026-10-26" },
];

const fallbackJobs = [
    { id: "job-101", title: "Community Coordinator", company: "Spark Foundation", type: "Full-time", location: "Remote", category: "Community", description: "Help create welcoming programs and connect women to local resources.", salary: "$48k–$58k" },
    { id: "job-102", title: "Content Strategist", company: "Rise Media", type: "Part-time", location: "Hybrid · Lahore", category: "Marketing", description: "Shape useful stories and campaigns for a growing social impact team.", salary: "$28–$35 / hour" },
    { id: "job-103", title: "Junior Product Designer", company: "HerTech Studio", type: "Full-time", location: "Remote", category: "Design", description: "Turn research into simple, accessible product experiences.", salary: "$55k–$68k" },
    { id: "job-104", title: "Program Intern", company: "Women in Tech Hub", type: "Internship", location: "On-site · Dhaka", category: "Programs", description: "Support workshops, speaker events, and participant success.", salary: "Paid internship" },
];

const fallbackApplications = [];
const mentors = [
    { name: "Mariam Hassan", expertise: "Business Growth", availability: "Available this week" },
    { name: "Zoya Ahmed", expertise: "Career Coaching", availability: "Open for 3 slots" },
    { name: "Farah Noor", expertise: "Digital Marketing", availability: "Accepting new mentees" },
];

let fallbackPosts = [
    { id: "post-201", author: "Leena S.", role: "Small business owner", time: "2 hours ago", content: "I made my first online sale this week! A small milestone, but it reminded me that consistency really does add up. What helped you find your first customers?", likes: 24, likedBy: [], comments: [{ id: "comment-1", author: "Rida", text: "Congratulations, Leena! Keep going." }] },
    { id: "post-202", author: "Hina M.", role: "Career changer", time: "Yesterday", content: "Hosting a free interview practice circle this Friday. Bring one question you have been nervous to answer and we will work through it together.", likes: 18, likedBy: [], comments: [] },
    { id: "post-203", author: "Rida A.", role: "Community mentor", time: "2 days ago", content: "A reminder for anyone building something new: you do not have to have the whole path figured out. One helpful conversation can be a great next step.", likes: 31, likedBy: [], comments: [] },
];

const dbReady = () => mongoose.connection.readyState === 1;

const ensureSeedData = async () => {
    if (!dbReady()) return;

    const profileCount = await Profile.countDocuments();
    if (profileCount === 0) {
        await Profile.create({ ...fallbackProfile, skills: fallbackProfile.skills });
    }

    const jobCount = await Job.countDocuments();
    if (jobCount === 0) {
        await Job.insertMany([
            {
                title: "Community Coordinator",
                company: "Spark Foundation",
                type: "Full-time",
                location: "Remote",
                category: "Community",
                description: "Help create welcoming programs and connect women to local resources.",
                salary: "$48k–$58k",
            },
            {
                title: "Content Strategist",
                company: "Rise Media",
                type: "Part-time",
                location: "Hybrid · Lahore",
                category: "Marketing",
                description: "Shape useful stories and campaigns for a growing social impact team.",
                salary: "$28–$35 / hour",
            },
            {
                title: "Junior Product Designer",
                company: "HerTech Studio",
                type: "Full-time",
                location: "Remote",
                category: "Design",
                description: "Turn research into simple, accessible product experiences.",
                salary: "$55k–$68k",
            },
            {
                title: "Program Intern",
                company: "Women in Tech Hub",
                type: "Internship",
                location: "On-site · Dhaka",
                category: "Programs",
                description: "Support workshops, speaker events, and participant success.",
                salary: "Paid internship",
            },
        ]);
    }

    const postCount = await Post.countDocuments();
    if (postCount === 0) {
        await Post.insertMany([
            {
                author: "Leena S.",
                role: "Small business owner",
                time: "2 hours ago",
                content: "I made my first online sale this week! A small milestone, but it reminded me that consistency really does add up. What helped you find your first customers?",
                likes: 24,
                likedBy: [],
                comments: [{ author: "Rida", text: "Congratulations, Leena! Keep going." }],
            },
            {
                author: "Hina M.",
                role: "Career changer",
                time: "Yesterday",
                content: "Hosting a free interview practice circle this Friday. Bring one question you have been nervous to answer and we will work through it together.",
                likes: 18,
                likedBy: [],
                comments: [],
            },
            {
                author: "Rida A.",
                role: "Community mentor",
                time: "2 days ago",
                content: "A reminder for anyone building something new: you do not have to have the whole path figured out. One helpful conversation can be a great next step.",
                likes: 31,
                likedBy: [],
                comments: [],
            },
        ]);
    }

    const mentorshipCount = await MentorshipRequest.countDocuments();
    if (mentorshipCount === 0) {
        await MentorshipRequest.insertMany([
            {
                name: "Samira Noor",
                email: "samira@example.com",
                area: "Career growth",
                mentor: "Zoya Ahmed",
                message: "I am preparing for a transition into product leadership.",
                status: "New",
            },
            {
                name: "Mina Rahman",
                email: "mina@example.com",
                area: "Business growth",
                mentor: "Mariam Hassan",
                message: "Looking for advice on pricing and first hires.",
                status: "Reviewing",
            },
        ]);
    }
};

router.use(async (req, res, next) => {
    try {
        if (dbReady()) await ensureSeedData();
    } catch (error) {
        // Ignore seed errors and continue with in-memory fallback data.
    }
    next();
});

const normalizeProfile = (document) => ({
    fullName: document.fullName,
    email: document.email,
    location: document.location,
    headline: document.headline,
    bio: document.bio,
    skills: document.skills || [],
    goals: document.goals,
});

const convertPost = (post) => ({
    id: post._id ? String(post._id) : post.id,
    author: post.author,
    role: post.role,
    time: post.time || "Just now",
    content: post.content,
    likes: post.likes || 0,
    likedBy: post.likedBy || [],
    comments: (post.comments || []).map((comment) => ({
        id: comment._id ? String(comment._id) : comment.id,
        author: comment.author,
        text: comment.text,
    })),
});

router.get("/profile", async (req, res) => {
    if (dbReady()) {
        let profile = await Profile.findOne().sort({ createdAt: -1 });
        if (!profile) {
            profile = await Profile.create({ ...fallbackProfile, skills: fallbackProfile.skills });
        }
        return res.json({ profile: normalizeProfile(profile) });
    }

    return res.json({ profile: fallbackProfile });
});

router.put("/profile", async (req, res) => {
    const nextProfile = {
        fullName: safeText(req.body?.fullName, 160) || fallbackProfile.fullName,
        email: safeText(req.body?.email, 160).toLowerCase() || fallbackProfile.email,
        location: safeText(req.body?.location, 160) || fallbackProfile.location,
        headline: safeText(req.body?.headline, 160) || fallbackProfile.headline,
        bio: safeText(req.body?.bio, 500) || fallbackProfile.bio,
        skills: Array.isArray(req.body?.skills) ? req.body.skills.map((skill) => safeText(skill, 50)).filter(Boolean).slice(0, 12) : fallbackProfile.skills,
        goals: safeText(req.body?.goals, 500) || fallbackProfile.goals,
    };

    if (dbReady()) {
        let profile = await Profile.findOne().sort({ createdAt: -1 });
        if (!profile) {
            profile = await Profile.create(nextProfile);
        } else {
            Object.assign(profile, nextProfile);
            await profile.save();
        }
        return res.json({ message: "Profile updated successfully", profile: normalizeProfile(profile) });
    }

    Object.assign(fallbackProfile, nextProfile);
    return res.json({ message: "Profile updated successfully", profile: fallbackProfile });
});

router.get("/mentorship", async (req, res) => {
    if (dbReady()) {
        const requests = await MentorshipRequest.find().sort({ createdAt: -1 }).lean();
        return res.json({ mentors, requests: requests.map((request) => ({
            id: String(request._id),
            name: request.name,
            email: request.email,
            area: request.area,
            mentor: request.mentor,
            message: request.message,
            status: request.status,
            createdAt: request.createdAt ? request.createdAt.toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
        })) });
    }

    return res.json({ mentors, requests: fallbackRequests });
});

router.post("/mentorship", async (req, res) => {
    const { name, email, area, mentor, message } = req.body || {};
    if (![name, email, area, message].every((value) => typeof value === "string" && value.trim())) {
        return res.status(400).json({ message: "Name, email, focus area, and a short note are required." });
    }

    const requestPayload = {
        name: safeText(name, 100),
        email: safeText(email, 160).toLowerCase(),
        area: safeText(area, 100),
        mentor: safeText(mentor, 100) || "Open to recommendations",
        message: safeText(message, 1000),
    };

    if (dbReady()) {
        const request = await MentorshipRequest.create(requestPayload);
        return res.status(201).json({
            message: "Your mentorship request has been sent.",
            request: {
                id: String(request._id),
                ...requestPayload,
                status: request.status,
                createdAt: request.createdAt.toISOString().slice(0, 10),
            },
        });
    }

    const request = {
        id: "ment-" + Date.now(),
        ...requestPayload,
        status: "New",
        createdAt: new Date().toISOString().slice(0, 10),
    };
    fallbackRequests.unshift(request);
    return res.status(201).json({ message: "Your mentorship request has been sent.", request });
});

router.delete("/mentorship/:id", async (req, res) => {
    if (dbReady()) {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(404).json({ message: "Mentorship request not found." });
        }

        const deletedRequest = await MentorshipRequest.findByIdAndDelete(req.params.id);
        if (!deletedRequest) {
            return res.status(404).json({ message: "Mentorship request not found." });
        }

        return res.json({ message: "Mentorship request deleted successfully." });
    }

    const requestIndex = fallbackRequests.findIndex((item) => item.id === req.params.id);
    if (requestIndex === -1) {
        return res.status(404).json({ message: "Mentorship request not found." });
    }

    fallbackRequests.splice(requestIndex, 1);
    return res.json({ message: "Mentorship request deleted successfully." });
});

router.get("/jobs", async (req, res) => {
    if (dbReady()) {
        const jobs = await Job.find().sort({ createdAt: -1 }).lean();
        return res.json({ jobs: jobs.map((job) => ({ id: String(job._id), ...job })) });
    }

    return res.json({ jobs: fallbackJobs });
});

router.post("/jobs/:id/apply", async (req, res) => {
    const jobId = req.params.id;

    if (dbReady()) {
        const job = await Job.findById(jobId);
        if (!job) {
            return res.status(404).json({ message: "Job listing not found." });
        }

        const email = safeText(req.body?.email, 160).toLowerCase();
        const name = safeText(req.body?.name, 100);
        if (!email || !name) {
            return res.status(400).json({ message: "Name and email are required to apply." });
        }

        const existing = await JobApplication.findOne({ jobId, email });
        if (existing) {
            return res.status(409).json({ message: "You have already applied to this role." });
        }

        const application = await JobApplication.create({
            jobId,
            title: job.title,
            company: job.company,
            name,
            email,
        });

        return res.status(201).json({
            message: `Application sent to ${job.company}.`,
            application: { id: String(application._id), jobId, title: job.title, company: job.company, name, email },
        });
    }

    const job = fallbackJobs.find((item) => item.id === jobId);
    if (!job) {
        return res.status(404).json({ message: "Job listing not found." });
    }

    const email = safeText(req.body?.email, 160).toLowerCase();
    const name = safeText(req.body?.name, 100);
    if (!email || !name) {
        return res.status(400).json({ message: "Name and email are required to apply." });
    }

    if (fallbackApplications.some((item) => item.jobId === job.id && item.email === email)) {
        return res.status(409).json({ message: "You have already applied to this role." });
    }

    const application = { id: "app-" + Date.now(), jobId: job.id, title: job.title, company: job.company, name, email, createdAt: new Date().toISOString() };
    fallbackApplications.push(application);
    return res.status(201).json({ message: `Application sent to ${job.company}.`, application });
});

router.delete("/jobs/applications/:id", async (req, res) => {
    if (dbReady()) {
        if (!mongoose.isValidObjectId(req.params.id)) {
            return res.status(404).json({ message: "Job application not found." });
        }

        const deletedApplication = await JobApplication.findByIdAndDelete(req.params.id);
        if (!deletedApplication) {
            return res.status(404).json({ message: "Job application not found." });
        }

        return res.json({ message: "Job application deleted successfully." });
    }

    const applicationIndex = fallbackApplications.findIndex((item) => item.id === req.params.id);
    if (applicationIndex === -1) {
        return res.status(404).json({ message: "Job application not found." });
    }

    fallbackApplications.splice(applicationIndex, 1);
    return res.json({ message: "Job application deleted successfully." });
});

router.get("/community", async (req, res) => {
    if (dbReady()) {
        const posts = await Post.find().sort({ createdAt: -1 }).lean();
        return res.json({ posts: posts.map(convertPost) });
    }

    return res.json({ posts: fallbackPosts });
});

router.post("/community", async (req, res) => {
    const content = safeText(req.body?.content, 1200);
    if (!content) {
        return res.status(400).json({ message: "Write a few words before sharing your post." });
    }

    const author = safeText(req.body?.author, 100) || "Community member";

    if (dbReady()) {
        const post = await Post.create({
            author,
            role: "Member",
            time: "Just now",
            content,
            likes: 0,
            likedBy: [],
            comments: [],
        });
        return res.status(201).json({ message: "Your post is live.", post: convertPost(post) });
    }

    const post = { id: "post-" + Date.now(), author, role: "Member", time: "Just now", content, likes: 0, likedBy: [], comments: [] };
    fallbackPosts.unshift(post);
    return res.status(201).json({ message: "Your post is live.", post });
});

router.post("/community/:id/like", async (req, res) => {
    const userId = safeText(req.body?.userId, 100) || "community-guest";

    if (dbReady()) {
        const post = await Post.findById(req.params.id);
        if (!post) return res.status(404).json({ message: "Post not found." });

        const liked = post.likedBy.includes(userId);
        post.likedBy = liked ? post.likedBy.filter((id) => id !== userId) : [...post.likedBy, userId];
        post.likes = Math.max(0, post.likes + (liked ? -1 : 1));
        await post.save();
        return res.json({ post: convertPost(post) });
    }

    const post = fallbackPosts.find((item) => item.id === req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });

    const liked = post.likedBy.includes(userId);
    post.likedBy = liked ? post.likedBy.filter((id) => id !== userId) : [...post.likedBy, userId];
    post.likes = Math.max(0, post.likes + (liked ? -1 : 1));
    return res.json({ post });
});

router.post("/community/:id/comments", async (req, res) => {
    const text = safeText(req.body?.text, 500);
    if (!text) {
        return res.status(400).json({ message: "Comment cannot be empty." });
    }

    const author = safeText(req.body?.author, 100) || "Community member";

    if (dbReady()) {
        const post = await Post.findById(req.params.id);
        if (!post) return res.status(404).json({ message: "Post not found." });

        post.comments.push({ author, text });
        await post.save();
        const comment = post.comments[post.comments.length - 1].toObject ? post.comments[post.comments.length - 1].toObject() : post.comments[post.comments.length - 1];
        return res.status(201).json({ comment: { id: String(comment._id || comment.id), author: comment.author, text: comment.text }, post: convertPost(post) });
    }

    const post = fallbackPosts.find((item) => item.id === req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });

    const comment = { id: "comment-" + Date.now(), author, text };
    post.comments.push(comment);
    return res.status(201).json({ comment, post });
});

router.get("/admin/dashboard", async (req, res) => {
    if (dbReady()) {
        const [requests, applications, posts] = await Promise.all([
            MentorshipRequest.find().sort({ createdAt: -1 }).lean(),
            JobApplication.find().sort({ createdAt: -1 }).lean(),
            Post.find().sort({ createdAt: -1 }).lean(),
        ]);

        return res.json({
            stats: {
                mentorshipRequests: requests.length,
                newRequests: requests.filter((item) => item.status === "New").length,
                jobApplications: applications.length,
                communityPosts: posts.length,
            },
            mentorshipRequests: requests.map((request) => ({
                id: String(request._id),
                name: request.name,
                email: request.email,
                area: request.area,
                mentor: request.mentor,
                message: request.message,
                status: request.status,
                createdAt: request.createdAt ? request.createdAt.toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
            })),
            recentApplications: applications.slice(-5).reverse().map((application) => ({
                id: String(application._id),
                jobId: String(application.jobId),
                title: application.title,
                company: application.company,
                name: application.name,
                email: application.email,
                createdAt: application.createdAt ? application.createdAt.toISOString() : new Date().toISOString(),
            })),
            note: "MongoDB-backed dashboard data is active when a database connection is available.",
        });
    }

    return res.json({
        stats: { mentorshipRequests: fallbackRequests.length, newRequests: fallbackRequests.filter((item) => item.status === "New").length, jobApplications: fallbackApplications.length, communityPosts: fallbackPosts.length },
        mentorshipRequests: fallbackRequests,
        recentApplications: fallbackApplications.slice(-5).reverse(),
        note: "Demo dashboard data is stored in memory and resets when the server restarts.",
    });
});

module.exports = router;

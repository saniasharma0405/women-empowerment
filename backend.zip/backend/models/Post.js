const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema(
    {
        author: { type: String, required: true, trim: true },
        text: { type: String, required: true, trim: true },
    },
    { timestamps: true }
);

const postSchema = new mongoose.Schema(
    {
        author: { type: String, required: true, trim: true },
        role: { type: String, default: "Member" },
        time: { type: String, default: "Just now" },
        content: { type: String, required: true, trim: true },
        likes: { type: Number, default: 0 },
        likedBy: [{ type: String }],
        comments: [commentSchema],
    },
    { timestamps: true }
);

module.exports = mongoose.model("Post", postSchema);

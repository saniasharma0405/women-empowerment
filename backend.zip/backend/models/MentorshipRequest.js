const mongoose = require("mongoose");

const mentorshipRequestSchema = new mongoose.Schema(
    {
        name: { type: String, required: true, trim: true },
        email: { type: String, required: true, trim: true, lowercase: true },
        area: { type: String, required: true, trim: true },
        mentor: { type: String, default: "Open to recommendations" },
        message: { type: String, required: true, trim: true },
        status: { type: String, enum: ["New", "Reviewing", "Accepted", "Closed"], default: "New" },
    },
    { timestamps: true }
);

module.exports = mongoose.model("MentorshipRequest", mentorshipRequestSchema);

const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema(
    {
        title: { type: String, required: true, trim: true },
        company: { type: String, required: true, trim: true },
        type: { type: String, required: true, trim: true },
        location: { type: String, required: true, trim: true },
        category: { type: String, required: true, trim: true },
        description: { type: String, required: true, trim: true },
        salary: { type: String, default: "Competitive" },
    },
    { timestamps: true }
);

module.exports = mongoose.model("Job", jobSchema);

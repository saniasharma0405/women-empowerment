const mongoose = require("mongoose");

const profileSchema = new mongoose.Schema(
    {
        fullName: { type: String, required: true, trim: true },
        email: { type: String, required: true, trim: true, lowercase: true },
        location: { type: String, default: "Karachi, Pakistan" },
        headline: { type: String, default: "Founder building a brighter future" },
        bio: { type: String, default: "Empowering women through growth, leadership, and opportunity." },
        skills: [{ type: String, trim: true }],
        goals: { type: String, default: "Build a more secure and confident future." },
    },
    { timestamps: true }
);

module.exports = mongoose.model("Profile", profileSchema);

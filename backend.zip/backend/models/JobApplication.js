const mongoose = require("mongoose");

const jobApplicationSchema = new mongoose.Schema(
    {
        jobId: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
        title: { type: String, required: true },
        company: { type: String, required: true },
        name: { type: String, required: true },
        email: { type: String, required: true, lowercase: true },
    },
    { timestamps: true }
);

module.exports = mongoose.model("JobApplication", jobApplicationSchema);

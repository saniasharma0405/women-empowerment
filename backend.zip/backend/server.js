const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

const authRoutes = require("./routes/authRoutes");

app.use("/api/auth", authRoutes);

const connectDB = async () => {
    const mongoUri = process.env.MONGO_URI;

    if (!mongoUri) {
        console.warn("MONGO_URI not set. Skipping MongoDB connection.");
        return;
    }

    try {
        await mongoose.connect(mongoUri);
        console.log("MongoDB Connected Successfully!");
    } catch (error) {
        console.log("MongoDB Connection Error:", error);
    }
};

app.get("/", (req, res) => {
    res.send("Women Empowerment Platform API is Running!");
});

app.get("/api/overview", (req, res) => {
    res.json({
        title: "Women Empowerment and Support Platform",
        summary: "A centralized digital platform connecting women entrepreneurs, learners, mentors, and job seekers.",
        modules: [
            {
                name: "Women Entrepreneur Profiles",
                description: "Create profiles, showcase businesses, and share achievements.",
                badge: "Profiles"
            },
            {
                name: "Skill-Sharing Community",
                description: "Share skills, host learning sessions, and discover courses.",
                badge: "Learning"
            },
            {
                name: "Mentorship Opportunities",
                description: "Find mentors and request guidance for personal and professional growth.",
                badge: "Mentors"
            },
            {
                name: "Jobs & Scholarships",
                description: "Browse opportunities for internships, jobs, and scholarships.",
                badge: "Careers"
            },
            {
                name: "Community Posts",
                description: "Share updates, comments, likes, and discussions with the community.",
                badge: "Community"
            }
        ],
        stats: [
            { label: "Women Entrepreneurs", value: "12K+" },
            { label: "Mentors", value: "1.8K" },
            { label: "Jobs Shared", value: "4.5K" },
            { label: "Community Posts", value: "28K" }
        ]
    });
});

app.get("/api/resources", (req, res) => {
    res.json({
        profiles: [
            { name: "Aisha Khan", role: "Fashion Entrepreneur", city: "Karachi", match: "92%" },
            { name: "Nadia Rahman", role: "Freelance Designer", city: "Dhaka", match: "88%" },
            { name: "Sara Ali", role: "Food Business Founder", city: "Lahore", match: "90%" }
        ],
        mentors: [
            { name: "Mariam Hassan", expertise: "Business Growth", availability: "Available this week" },
            { name: "Zoya Ahmed", expertise: "Career Coaching", availability: "Open for 3 slots" },
            { name: "Farah Noor", expertise: "Digital Marketing", availability: "Accepting new mentees" }
        ],
        jobs: [
            { title: "Community Coordinator", company: "Spark Foundation", type: "Full-time", location: "Remote" },
            { title: "Content Strategist", company: "Rise Media", type: "Part-time", location: "Hybrid" },
            { title: "Project Intern", company: "Women in Tech Hub", type: "Internship", location: "On-site" }
        ],
        posts: [
            { author: "Leena", title: "How I grew my small business online", likes: 121 },
            { author: "Hina", title: "Workshop: Building confidence in interviews", likes: 86 },
            { author: "Rida", title: "Resources for women in leadership", likes: 143 }
        ]
    });
});

app.use('/api', require('./routes/platformRoutes'));

if (require.main === module) {
    const PORT = process.env.PORT || 5000;
    connectDB();

    app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });
}

module.exports = app;
module.exports.connectDB = connectDB;


const jwt = require("jsonwebtoken");

const protect = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ message: "Authorization token missing or invalid" });
    }

    const token = authHeader.split(" ")[1];

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || "women_empowerment_secret");
        req.user = decoded;
        return next();
    } catch (error) {
        return res.status(401).json({ message: "Token is invalid or expired" });
    }
};

module.exports = { protect };
